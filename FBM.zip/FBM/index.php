<!-- Incluimos un codigo php  -->
<?php
include("layout/menu.php");
include("layout/header.php");
include("layout/footer.php");
?>
